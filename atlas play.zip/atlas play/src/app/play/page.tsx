import AtlasGame from '@/components/game/AtlasGame';

export default function PlayPage() {
  return <AtlasGame />;
}
